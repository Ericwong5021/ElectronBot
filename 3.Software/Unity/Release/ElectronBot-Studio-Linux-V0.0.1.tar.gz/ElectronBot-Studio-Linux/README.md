## ElectronBot-Studio Linux

### TODO

    1. ElectronBotSDK 动态库
    2. USB driver

### Changelog

    V0.0.1

    1. 添加新字体修复Linux(Mint)部分中文不显示问题
    2. 修改File Browser为UnityStandaloneFileBrowser，支持Linux下的文件浏览(选择图片)
